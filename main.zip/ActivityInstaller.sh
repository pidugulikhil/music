apt update -y
pkg install ffmpeg -y
pkg install x11-repo -y
pkg install ffplay -y
mkdir default
cp -r words.mp3 default
if [ "$(cat $HOME/.bashrc | grep ffplay)" == "ffplay -autoexit -nodisp /data/data/com.termux/files/home/music/words.mp3 > /dev/null 2>&1 &" ]; then
	echo -e "\e[32mALREADY INSTALLED, use 'music help' to view all options"
else
	chmod +x *
	sleep 1
	echo -e  "\e[34mMOVING ITEMS ..."
	mv music /data/data/com.termux/files/usr/bin/
	chmod +x /data/data/com.termux/files/usr/bin/music
	echo -e ".....COMPLETED...\e[0m"
	echo ""
	sleep 2
	if [ "$(cat $HOME/.bashrc | grep ffplay)" == "ffplay -autoexit -nodisp /data/data/com.termux/files/home/music/words.mp3 > /dev/null 2>&1 &" ]; then
		echo -e "\e[35mMUSIC ALREADY CONFIGURED CONFIGURED, REMOVING AND ADDING NEW CONFIGURATION"
		sedsed -i 's|ffplay -autoexit -nodisp /data/data/com.termux/files/home/music/words.mp3 > /dev/null 2>&1 &| |g' /data/data/com.termux/files/home/.bashrc
		echo "ffplay -autoexit -nodisp $HOME/music/words.mp3 > /dev/null 2>&1 &" >> /data/data/com.termux/files/home/.bashrc
	else
		echo "ffplay -autoexit -nodisp $HOME/music/words.mp3 > /dev/null 2>&1 &" >> /data/data/com.termux/files/home/.bashrc
	fi
	sleep 1
	echo -e "\e[34mMusic configured successfully"
	echo ""
	sleep 2
	clear
	if [ "$(cat $HOME/.bashrc | grep ffplay)" == "ffplay -autoexit -nodisp /data/data/com.termux/files/home/music/words.mp3 > /dev/null 2>&1 &" ]; then
		echo -e "\e[32mIntro music Installed Successfully. To know more, use 'music help'"
	else
		echo -e "\e[31mERROR IN INSTALLATION... RETRY AGAIN"
	fi
fi
echo -e "\e[0m"
